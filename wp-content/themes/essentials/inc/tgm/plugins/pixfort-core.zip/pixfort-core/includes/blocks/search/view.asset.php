<?php return array('dependencies' => array(), 'version' => '7a59f1e066bd4ec7bded');
