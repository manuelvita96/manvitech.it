<?php




function pix_elementor_templates_heading(){
    $templates = array();
    $thumb_path = 'https://pixfort-space.sfo2.cdn.digitaloceanspaces.com/wordpress/essentials/data/thumbnails/headings/';

    $data = array (
        'id' => 'consulting-heading',
        'file' => 'sections/heading/consulting-heading.json',
        'title' => 'Heading Consulting',
        'thumbnail' => $thumb_path.'consulting-heading.webp',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/consulting-elementor/templates-library/?template=consulting-heading',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'digital-agency-heading',
        'file' => 'sections/heading/digital-agency-heading.json',
        'title' => 'Heading Digital Agency',
        'thumbnail' => $thumb_path.'digital-agency-heading.webp',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/digital-agency-elementor/templates-library/?template=digital-agency-heading',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'digital-agency-heading-circles',
        'file' => 'sections/heading/digital-agency-heading-circles.json',
        'title' => 'Heading circles Digital Agency',
        'thumbnail' => $thumb_path.'digital-agency-heading-circles.webp',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/digital-agency-elementor/templates-library/?template=digital-agency-heading-circles',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'minimal-heading',
        'file' => 'sections/heading/minimal-heading.json',
        'title' => 'Heading Minimal',
        'thumbnail' => $thumb_path.'minimal-heading.webp',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/minimal-elementor/templates-library/?template=minimal-heading',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'gallery-heading',
        'file' => 'sections/heading/gallery-heading.json',
        'title' => 'Gallery heading',
        'thumbnail' => $thumb_path.'gallery-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/gallery-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'gallery-gallery-page-heading',
        'file' => 'sections/heading/gallery-gallery-page-heading.json',
        'title' => 'Gallery page heading',
        'thumbnail' => $thumb_path.'gallery-gallery-page-heading.jpg',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/gallery-elementor/gallery/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'startup-heading',
        'file' => 'sections/heading/startup-heading.json',
        'title' => 'Startup heading',
        'thumbnail' => $thumb_path.'startup-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/startup/homepage-startup-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'software-heading',
        'file' => 'sections/heading/software-heading.json',
        'title' => 'software heading',
        'thumbnail' => $thumb_path.'software-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/software/homepage-software-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'saas-heading',
        'file' => 'sections/heading/saas-heading.json',
        'title' => 'saas heading',
        'thumbnail' => $thumb_path.'saas-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/saas/homepage-saas-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'saas-heading-dark',
        'file' => 'sections/heading/saas-heading-dark.json',
        'title' => 'saas heading dark',
        'thumbnail' => $thumb_path.'saas-heading-dark.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/saas/homepage-saas-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'crypto-heading',
        'file' => 'sections/heading/crypto-heading.json',
        'title' => 'crypto-heading',
        'thumbnail' => $thumb_path.'crypto-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/cryptocurrency/homepage-cryptocurrency-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'services-heading',
        'file' => 'sections/heading/services-heading.json',
        'title' => 'services-heading',
        'thumbnail' => $thumb_path.'services-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/services/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'medical-heading',
        'file' => 'sections/heading/medical-heading.json',
        'title' => 'medical-heading',
        'thumbnail' => $thumb_path.'medical-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/medical/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'marketing-heading',
        'file' => 'sections/heading/marketing-heading.json',
        'title' => 'marketing-heading',
        'thumbnail' => $thumb_path.'marketing-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/marketing/homepage-marketing-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'creative-heading',
        'file' => 'sections/heading/creative-heading.json',
        'title' => 'creative-heading',
        'thumbnail' => $thumb_path.'creative-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/creative/homepage-creative-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'creative-heading-simple',
        'file' => 'sections/heading/creative-heading-simple.json',
        'title' => 'creative-heading-simple',
        'thumbnail' => $thumb_path.'creative-heading-simple.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/creative/homepage-creative-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'ebook-heading',
        'file' => 'sections/heading/ebook-heading.json',
        'title' => 'ebook-heading',
        'thumbnail' => $thumb_path.'ebook-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/ebook/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'restaurant-heading',
        'file' => 'sections/heading/restaurant-heading.json',
        'title' => 'restaurant-heading',
        'thumbnail' => $thumb_path.'restaurant-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/restaurant/homepage-restaurant-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'business-heading',
        'file' => 'sections/heading/business-heading.json',
        'title' => 'business-heading',
        'thumbnail' => $thumb_path.'business-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/business/homepage-business-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'product-heading-circles',
        'file' => 'sections/heading/product-heading-circles.json',
        'title' => 'product-heading-circles',
        'thumbnail' => $thumb_path.'product-heading-circles.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/product/homepage-product-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'coronavirus-heading-circles',
        'file' => 'sections/heading/coronavirus-heading-circles.json',
        'title' => 'coronavirus-heading-circles',
        'thumbnail' => $thumb_path.'coronavirus-heading-circles.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/coronavirus/homepage-coronavirus-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'influencer-heading',
        'file' => 'sections/heading/influencer-heading.json',
        'title' => 'influencer-heading',
        'thumbnail' => $thumb_path.'influencer-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/influencer/homepage-influencer-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'photography-heading',
        'file' => 'sections/heading/photography-heading.json',
        'title' => 'photography-heading',
        'thumbnail' => $thumb_path.'photography-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/photography/homepage-photography-elementor/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'beauty-heading',
        'file' => 'sections/heading/beauty-heading.json',
        'title' => 'beauty-heading',
        'thumbnail' => $thumb_path.'beauty-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/beauty/homepage-beauty-elementor',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'original-main-heading',
        'file' => 'sections/heading/original-main-heading.json',
        'title' => 'original-main-heading',
        'thumbnail' => $thumb_path.'original-main-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/original/homepage-original-elementor',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);


    return $templates;
}




 ?>
