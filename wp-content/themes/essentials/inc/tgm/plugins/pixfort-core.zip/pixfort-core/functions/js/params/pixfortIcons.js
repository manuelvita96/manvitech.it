!(function ($) {
    $('body').trigger('pixfortIconsParam');
    // console.log('pixfortIconsParam');
})(window.jQuery);