<?php

namespace PixScssPhp\ScssPhp\Exception;

interface SassException
{
}
